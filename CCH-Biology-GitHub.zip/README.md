# CCH Biology

Biology material for cadets of Cadet College Hasanabdal: Cambridge O Level (5090), IGCSE (0610 / 0970) and A Level (9700).
Slides by chapter, past papers by year and session, syllabuses and practical guides.

**Open the website:** sign in with your **@cch.edu.pk** Google account.

## What is in this repository

| File | What it is |
|---|---|
| `index.html` | The front page shown on GitHub Pages. It sends visitors to the CCH Biology web app. |
| `apps-script/Code.gs` | The full website code. It runs in Google Apps Script, not on GitHub. |
| `qr-code.png` | QR code for notice boards and classrooms. |

## Updating the website

1. Open the project at script.google.com.
2. Paste `apps-script/Code.gs` into `Code.gs` and save.
3. Deploy › Manage deployments › edit › New version › Deploy.

Maintained by the Biology Department, Cadet College Hasanabdal.
