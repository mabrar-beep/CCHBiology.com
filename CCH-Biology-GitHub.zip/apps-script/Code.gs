/******************************************************************
 *  CCH Biology — Google Apps Script web app (single file)
 *  Paste this whole file into Code.gs. No other file is needed.
 *  O Level 5090 · IGCSE 0610 / 0970 · A Level 9700
 *
 *  Deploy as: Execute as "Me", Who has access "Anyone within
 *  Cadet College Hasanabdal". Google then only lets in people
 *  signed in with an @cch.edu.pk account.
 ******************************************************************/

const CONFIG = {
  SCHOOL_DOMAIN: 'cch.edu.pk',

  // Teachers can open the locked (latest-year) papers. Add or remove emails here.
  TEACHERS: [
    'm.abrar@cch.edu.pk',
    'm.ashiq@cch.edu.pk',
    'm.r.maqbool@cch.edu.pk',
    't.masood@cch.edu.pk'
  ],

  // How many of the most recent exam years are locked for students.
  LOCK_LATEST_YEARS: 1,

  LEVELS: [
    {
      key: 'o', name: 'O Level', code: '5090',
      papers: [{ label: 'O Level 5090', id: '1AvQi0twausvRutqRdKUEOuCbKLK4I3uG' }],
      collections: [
        { name: 'Syllabus', desc: 'Cambridge 5090 syllabus', folder: '19f8t9Pnq3biyFj_iRDbyox8Y38P6shsZ' },
        { name: 'Learner Guide', desc: 'For examination from 2023', file: '1AQZYLnS3bETpa0Gh1gIzDnNoKmmbzFKC' },
        { name: 'ATP skills (Paper 4)', desc: 'Alternative to Practical', folder: '1jsbK9um9YFyfPkOUhiCP9lcHt5mAWoDE' },
        { name: 'Paper 4 ATP slides', desc: 'Practical skills lesson', file: '1DtXZHhnLnOcLTvAkPipNbo1j7KcaVXb2' },
        { name: 'Example candidate responses', desc: 'Marked answers with examiner comments', folder: '197gQxwG0qbD0bThYAlktB__MxaLI2FuR' },
        { name: 'Specimen answers 2023', desc: 'Specimen paper answers', folder: '1ZvXWD0qqgBYqgAqI1P7vlkQ19ZZA9IZ_' },
        { name: 'Sample papers', desc: 'Specimen and sample papers', folder: '19_f_R0zaYoUb6Hxv4XE-wRJkuSrYm7oP' },
        { name: 'Scheme of work', desc: 'Teaching order and plan', folder: '19kRdKQOQm2BiEQ_fjQjymA0dszY48guN' }
      ],
      topics: [
        [1, 'Cells', 'cell organelle nucleus mitochondria chloroplast microscope specialised tissue organ', [['Ch 1 Cells', '17Hdv2fSP5kKBMw4MTi7stmlIxsmacPyb', 'ppt']]],
        [2, 'Classification', 'kingdom species binomial dichotomous key vertebrates invertebrates', [['Classification 1', '1x8SGOy3NCDNanUmFEdk9EOsJxQc5eYDX', 'pdf'], ['Classification 2', '1x8JrHHQ4p0sqw4Jf3mWkYR5ZazWFy_pO', 'pdf']]],
        [3, 'Movement into and out of cells', 'diffusion osmosis active transport water potential turgid plasmolysis', []],
        [4, 'Biological molecules', 'carbohydrate protein lipid starch glucose food test benedict biuret iodine DNA', [['Ch 4 Biological molecules', '1wxsPmKZEo1oBPhmmMsxQK1_j8AL5peu9', 'ppt']]],
        [5, 'Enzymes', 'catalyst active site substrate temperature pH denature amylase protease lipase', [['Ch 5 Enzymes', '1jdnTrzpUU5kVjsy-99DS-ShN01ZXetC-', 'ppt']]],
        [6, 'Plant nutrition', 'photosynthesis chlorophyll leaf stomata limiting factor light carbon dioxide mineral nitrate magnesium', [['Ch 6 Plant nutrition', '1wdCdCmMI8t5AURObSHD6FykU9NEdI_-R', 'ppt']]],
        [7, 'Transport in flowering plants', 'xylem phloem transpiration translocation root hair wilting', [['Ch 7 Transport in flowering plants', '1wXDYDl5XZn8mODLiEGMdIwPYCjXhZ_YP', 'ppt']]],
        [8, 'Human nutrition', 'diet digestion teeth stomach intestine absorption villi liver bile', [['Ch 8 Human nutrition', '1x2hSvuSnlBNiF05THM-sK79X9c5sVdUh', 'ppt']]],
        [9, 'Human gas exchange', 'lungs alveoli breathing ventilation trachea bronchi diaphragm', [['Ch 9 Human gas exchange', '1D8vr8xiW2PvRfjttW-47wyzUgbGklgs0', 'ppt'], ['Ch 9 Gaseous exchange (T. Masood)', '1j8YJpG1wikwO-kNEfzoudy8yT10dqxpE', 'ppt']]],
        [10, 'Respiration', 'aerobic anaerobic lactic acid oxygen debt yeast fermentation energy', []],
        [11, 'Transport in humans', 'heart blood vessels artery vein capillary circulation plasma haemoglobin coronary', [['Ch 11 Transport in humans', '1wMXgwEtoPwsx2eGjV7po6hq3wnXSx1L7', 'ppt']]],
        [12, 'Disease and immunity', 'pathogen antibody antigen vaccination lymphocyte phagocyte cholera defence', [['Ch 12 Diseases & immunity', '1-V7B-DbUdzpJdsg0tRfg4QtJw3SgLDhy', 'ppt']]],
        [13, 'Excretion', 'kidney nephron urea urine dialysis deamination', [['Ch 13 Excretion', '1wVjv0cl6HF0HNSoFl6gNPj-I7DfkK8ZG', 'ppt']]],
        [14, 'Co-ordination and control', 'nervous system neuron reflex eye hormone insulin adrenaline homeostasis temperature tropism auxin', [['Ch 14 Co-ordination and control', '1wVGObpjYIyKzeVzmk9Y9B1GBaya8r-Wo', 'ppt'], ['Coordination in plants', '1x5o8ZerivrW5B5_SceAIN-7bgcFD-i3O', 'pdf']]],
        [15, 'Drugs', 'antibiotic heroin alcohol tobacco smoking resistance', []],
        [16, 'Development of organisms and continuity of life', 'reproduction asexual sexual flower pollination fertilisation menstrual mitosis meiosis chromosome', [['Ch 16 Part 1', '168Rvc8w2f0YO42lgMeUgo_RGmjmiEVVI', 'ppt'], ['Ch 16 Part 2', '17BGEnqEg1D_xy40zv-XhGWlR1hDt6ZJP', 'ppt']]],
        [17, 'Inheritance', 'genetics gene allele dominant recessive genotype phenotype monohybrid punnett variation mutation selection', [['Ch 17 Inheritance', '1826YYrOUkKC6EAyBYxXQjqL8I3aGLOo9', 'ppt']]],
        [18, 'Biotechnology and genetic modification', 'bacteria yeast insulin plasmid restriction enzyme GM crops fermenter', [['Ch 18 Biotechnology & GM', '1DTudvDhQdT9bMQ5TeDr-oYrOreMivNs1', 'ppt']]],
        [19, 'Relationships of organisms with the environment', 'ecology food chain web pyramid energy flow carbon cycle nitrogen cycle population pollution conservation', [['Ch 19 Relationships with environment', '1DG8YxsXHWiMgZqd2pTsBArJI5ReLNT-F', 'ppt']]]
      ]
    },
    {
      key: 'ig', name: 'IGCSE', code: '0610 · 0970',
      papers: [
        { label: 'IGCSE 0610', id: '17cKZPcSiSwWx27tjKmt_oTGYU3WDWr5H' },
        { label: 'IGCSE 0970 (9–1)', id: '18ytcTCJgFh9QBObc8CrctOaO8R9e8jlz' }
      ],
      collections: [
        { name: '0610 Syllabus', desc: 'IGCSE Biology 0610', folder: '19TtHeVSZFYxcIymigdLVmeJZ7OwbyXXw' },
        { name: '0610 Sample papers', desc: 'Specimen and sample papers', folder: '19gwr15yCfWnSybI-EgccEMYU7IY1f9VM' },
        { name: '0970 Syllabus', desc: 'IGCSE Biology 0970 (9–1)', folder: '18zucXtKI7fxmYbK173xKXi446r-2Qdqn' }
      ],
      topics: []
    },
    {
      key: 'a', name: 'A Level', code: '9700',
      papers: [{ label: 'A Level 9700', id: '1l2zvV7-rIsH7D9eNamIDxTmAW24f_NVu' }],
      collections: [
        { name: 'Syllabuses', desc: 'Cambridge 9700 syllabus', folder: '1FTr0mvS3nevg77mDTA19p11IrxBQTana' },
        { name: 'Topical questions', desc: 'Past paper questions by chapter', folder: '1cuHu_xPOMUJmmGpxlvSd1-d2zCRU2htN' },
        { name: 'Questions and answers', desc: 'Practice questions with answers', folder: '11W65mQFwIHYMokSxs4ciLEcITfRT2a8S' },
        { name: 'Practical', desc: 'Paper 3 and Paper 5 material', folder: '1FA7xnjiClQxf9m26FLLdH8cVQfW9cJvr' },
        { name: 'Practical skills', desc: 'Practical skills material', folder: '1uSRrYeMNTZn-MVM6ZwdKHNoOFzUwrv_h' },
        { name: 'A2 Paper 5 slides', desc: 'Planning and evaluation lessons', file: '1QiHTR9IXqqmbM0IXRLIY1oUMbHp2wnPX' },
        { name: 'A2 practical activities', desc: 'Required practical activities', file: '1THN1HgS8Xy3mpQvOkB7Rv_4g_3Vfmviq' },
        { name: 'Data sheets', desc: 'Data analysis practice', folder: '1tXZFFegl24pmWZEtNOm15Rls7kwT1fSB' },
        { name: 'Grade descriptions', desc: 'What each grade needs', folder: '1BeBLuB68f-SBSGYiE5FgxtJQT1h_bVpJ' },
        { name: 'Sample paper 2022', desc: 'Specimen papers', folder: '1FDqjQEJnUiskYDcjD2VgNwP_77rRRSXJ' },
        { name: 'Sample paper 2016', desc: 'Specimen papers', folder: '1FEk0UNjikCb3o03cfRa-g1fzy41nIAUW' },
        { name: 'Student responses', desc: 'Example answers', folder: '1FXpAiQoWvu3V5uUHfkxALBjXDT8qPLBl' },
        { name: 'Scheme of work', desc: 'Teaching order and plan', folder: '1FX4e_I_4pvR8iXabLtSyNE5OwCZsnmTh' }
      ],
      topics: [
        [1, 'Cell structure', 'organelle microscope magnification resolution eukaryote prokaryote virus', [['Chapter 1 A level', '1DMnThyLPideWYBtxoN6zFqAIBgAw3AbG', 'ppt'], ['Topical Ch 1 Paper 1', '1cwUDsb9KJRvKVC7SSE6_AdBONTU2WcYR', 'doc'], ['Topical Ch 1 Paper 2', '1cvWlF2gY_aGjAJLSLiBn_USFyOE9IKI6', 'pdf']]],
        [2, 'Biological molecules', 'carbohydrate glucose starch cellulose glycogen lipid triglyceride phospholipid protein amino acid water', [['Biological molecules', '10DXV7yyorch1XR7qpIA1Q-wfIFbegiAA', 'ppt'], ['Carbohydrates', '1-VknDVhFRDCS3A1ezmYB4oHlMvp7TPu2', 'ppt'], ['Lipids', '1-YzZCOlesW92q40z3EJBoQcrVxZe8egX', 'ppt'], ['Proteins', '1-kIs5dShRq1olgc57hdctDBzjoD0NfHU', 'ppt'], ['Topical Ch 2 Paper 2', '1cwsHXg25T8_dM026EV5grV2bt9WDadIZ', 'doc']]],
        [3, 'Enzymes', 'active site inhibition competitive non-competitive Vmax Km induced fit', [['AS Enzymes', '107OCoEHYoXHL7NX4sYihT3dzMJIVPprz', 'ppt']]],
        [4, 'Cell membranes and transport', 'fluid mosaic diffusion osmosis active transport endocytosis exocytosis water potential', [['AS Cell membrane', '1057u_XfmxlyQAU6WNYa558F7124Twziu', 'ppt']]],
        [5, 'The mitotic cell cycle', 'mitosis chromosome telomere stem cell cancer interphase', [['Mitosis A level', '16ylwKjjr-u6ccOvlga19Kb_Fh12GdjEs', 'ppt']]],
        [6, 'Nucleic acids and protein synthesis', 'DNA RNA replication transcription translation codon mutation gene', [['Nucleic acid 1', '18IaaBVULv91TaLIexPmYBaeiTVjk7Tlz', 'ppt']]],
        [7, 'Transport in plants', 'xylem phloem transpiration mass flow apoplast symplast translocation', [['AS Transport in plants', '18I2NjTCMxvlB_tXGQnOdo9w97a4CPgu7', 'ppt']]],
        [8, 'Transport in mammals', 'heart cardiac cycle blood vessels haemoglobin oxygen dissociation Bohr tissue fluid', [['AS Transport in mammals', '18DKeV06Sqs6Ua4BKF8w5ll5uWcK6B12R', 'ppt']]],
        [9, 'Gas exchange', 'lungs alveoli trachea bronchi smoking', [['A level Gas exchange', '18euBvKGXjbQI0OC5VbpGhw-oXNVvRJ0H', 'ppt']]],
        [10, 'Infectious diseases', 'cholera malaria tuberculosis HIV AIDS measles antibiotic resistance', [['Infectious diseases AS', '1N2qQWaW4Kyc9pFRakSqIag1Qsy3spp95', 'ppt']]],
        [11, 'Immunity', 'antibody antigen B cell T cell vaccination monoclonal phagocyte', [['Immunity', '1N2ry1OIrMfpyUhc_75HaYD1WVhF5jGiM', 'ppt']]],
        [12, 'Energy and respiration', 'ATP glycolysis Krebs cycle oxidative phosphorylation respiratory quotient anaerobic', [['Respiration A2', '1rp1Znta8GMEMNt5F4e49-7a8MEIiyniM', 'ppt']]],
        [13, 'Photosynthesis', 'light dependent light independent Calvin cycle chloroplast limiting factor', [['A2 Photosynthesis', '1ILvjiMU47bJ41BGBQwQIeyHf9YF_aU0q', 'ppt']]],
        [14, 'Homeostasis', 'kidney blood glucose insulin glucagon negative feedback stomata', []],
        [15, 'Control and co-ordination', 'nerve impulse action potential synapse muscle hormone plant hormone auxin', [['A2 Control and co-ordination', '1ZA7PZaM-zWYzC4AtwIll07LT4YVQrnt-', 'ppt']]],
        [16, 'Inheritance', 'meiosis dihybrid chi-squared epistasis linkage gene control', [['A2 Inheritance Ch 16', '1-5PLoHP5A8at9CA_b_4KgaxqKmD_0vf-', 'ppt'], ['A2 Inheritance', '1uF_IdRVOZa01MQeUUyfo0t1mSNcOw2Mc', 'ppt']]],
        [17, 'Selection and evolution', 'natural selection Hardy-Weinberg variation speciation artificial selection', [['A2 Selection and evolution', '1cRS8HiPXsbfnkl_fe1gbmOmkRdhNUMI6', 'ppt'], ['The Hardy–Weinberg principle', '1ClbScPPI3MpWfCq1PNUhxXD2jDM29q-K', 'ppt'], ['Molecular evidence for evolution', '1xYtiL9Ti4X6oU6wytacBBOfHfdhUVijT', 'ppt']]],
        [18, 'Classification, biodiversity and conservation', 'domain kingdom Simpson index sampling quadrat conservation', []],
        [19, 'Genetic technology', 'PCR gel electrophoresis recombinant DNA gene therapy CRISPR genetic engineering', [['Genetic engineering A level', '1njwktWYnISAwm_dqatGscbJmdWXQC0L0', 'ppt'], ['Genetic engineering (short version)', '1NmK4W2AmXCbR2RYDEZBGXc_rEwYT59Yj', 'ppt']]],
        ['Skills', 'Statistics and data analysis', 'statistics t-test chi-squared standard deviation Spearman Pearson correlation', [['Statistical analysis A2', '1EDfv0XtxCykUtswlzeUV2Rw5y10L5_Vj', 'ppt'], ['Data analysis', '1HnteS8o8LQKAqGZytjMg2kttG6NR30Sf', 'ppt']]]
      ]
    }
  ]
};

/* ---------------------------------------------------------------
 *  Web app entry
 * ------------------------------------------------------------- */
function doGet() {
  // The material is placed inside the page itself, so the site works even when
  // the visitor is signed in to several Google accounts at once.
  const t = HtmlService.createTemplate(pageHtml_());
  t.boot = getData().replace(/</g, '\\u003c');
  return t.evaluate()
    .setTitle('CCH Biology')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/** Link that opens Google's account chooser and then returns to the site with the chosen account. */
function switchUrl_() {
  let url = ScriptApp.getService().getUrl() || '';
  if (url.indexOf('/a/macros/') === -1) url = url.replace('/macros/s/', '/a/macros/' + CONFIG.SCHOOL_DOMAIN + '/s/');
  return 'https://accounts.google.com/AccountChooser?continue=' + encodeURIComponent(url);
}

/** Link that goes straight to Google's email and password screen, then returns to the site. */
function addUrl_() {
  let url = ScriptApp.getService().getUrl() || '';
  if (url.indexOf('/a/macros/') === -1) url = url.replace('/macros/s/', '/a/macros/' + CONFIG.SCHOOL_DOMAIN + '/s/');
  return 'https://accounts.google.com/AddSession?hd=' + CONFIG.SCHOOL_DOMAIN + '&continue=' + encodeURIComponent(url);
}

/** Called by the page. Returns the index as a JSON string, with locked file links removed for students. */
function getData() {
  const email = currentEmail_();
  if (!email.endsWith('@' + CONFIG.SCHOOL_DOMAIN)) return JSON.stringify({ denied: true, email: email, switchUrl: switchUrl_(), addUrl: addUrl_() });
  const teacher = CONFIG.TEACHERS.map(function (s) { return s.toLowerCase(); }).indexOf(email) !== -1;
  let raw = loadIndex_();
  if (!raw) {
    // First visit: build the file list automatically (takes a minute once).
    try { buildIndex(); raw = loadIndex_(); }
    catch (e) { return JSON.stringify({ empty: true, error: String(e), user: { email: email, teacher: teacher, switchUrl: switchUrl_(), addUrl: addUrl_() } }); }
  }
  if (!raw) return JSON.stringify({ empty: true, user: { email: email, teacher: teacher, switchUrl: switchUrl_(), addUrl: addUrl_() } });
  const data = JSON.parse(raw);
  if (!teacher) data.levels.forEach(function (lv) {
    lv.papers.forEach(function (p) { stripLocked_(p.node); });
  });
  data.user = { email: email, teacher: teacher, switchUrl: switchUrl_(), addUrl: addUrl_() };
  return JSON.stringify(data);
}

/* ---------------------------------------------------------------
 *  Index: reads your Drive folders and saves a list of every file.
 *  Run once by hand, then setupDailyRefresh() keeps it up to date.
 * ------------------------------------------------------------- */
function buildIndex() {
  const out = { built: new Date().toISOString(), lockYears: CONFIG.LOCK_LATEST_YEARS, levels: [] };
  CONFIG.LEVELS.forEach(function (L) {
    const lv = { key: L.key, name: L.name, code: L.code, topics: L.topics, papers: [], collections: [] };
    L.papers.forEach(function (p) {
      try {
        const node = walk_(DriveApp.getFolderById(p.id), 0, 4);
        markLocks_(node);
        lv.papers.push({ label: p.label, node: node });
      } catch (e) { Logger.log('Skipped ' + p.label + ': ' + e); }
    });
    L.collections.forEach(function (c) {
      try {
        if (c.file) {
          const f = DriveApp.getFileById(c.file);
          lv.collections.push({ name: c.name, desc: c.desc, file: [f.getName(), c.file, kind_(f.getMimeType())] });
        } else {
          lv.collections.push({ name: c.name, desc: c.desc, node: walk_(DriveApp.getFolderById(c.folder), 0, 4) });
        }
      } catch (e) { Logger.log('Skipped ' + c.name + ': ' + e); }
    });
    out.levels.push(lv);
  });
  saveIndex_(JSON.stringify(out));
  Logger.log('Index built: ' + countFiles_(out) + ' files.');
}

function walk_(folder, depth, maxDepth) {
  const node = { n: folder.getName(), f: [], d: [] };
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if (f.isTrashed()) continue;
    node.f.push([f.getName(), f.getId(), kind_(f.getMimeType())]);
  }
  if (depth < maxDepth) {
    const subs = folder.getFolders();
    while (subs.hasNext()) {
      const s = subs.next();
      if (!s.isTrashed()) node.d.push(walk_(s, depth + 1, maxDepth));
    }
  }
  node.f.sort(function (a, b) { return natCmp_(a[0], b[0]); });
  node.d.sort(function (a, b) { return natCmp_(a.n, b.n); });
  return node;
}

/** Locks the latest exam year(s): year folders like "2026" and files named like 9700_s26_qp_22. */
function markLocks_(root) {
  const years = {};
  root.d.forEach(function (d) { if (/^\d{4}$/.test(d.n.trim())) years[+d.n.trim()] = 1; });
  eachFile_(root, function (f) { const y = fileYear_(f[0]); if (y) years[y] = 1; });
  const locked = Object.keys(years).map(Number).sort(function (a, b) { return b - a; })
    .slice(0, CONFIG.LOCK_LATEST_YEARS);
  root.d.forEach(function (d) {
    if (locked.indexOf(+d.n.trim()) !== -1) { d.L = 1; eachFile_(d, function (f) { f[3] = 1; }); }
  });
  eachFile_(root, function (f) { const y = fileYear_(f[0]); if (y && locked.indexOf(y) !== -1) f[3] = 1; });
  root.locked = locked;
}

function stripLocked_(node) {
  node.f.forEach(function (f) { if (f[3]) f[1] = null; });
  node.d.forEach(stripLocked_);
}

/** Run this from the editor to check the site's data. The log shows what the page would receive. */
function testGetData() {
  const json = getData();
  const d = JSON.parse(json);
  if (d.denied) Logger.log('Your account is not @' + CONFIG.SCHOOL_DOMAIN + ': ' + currentEmail_());
  else if (d.empty) Logger.log('No file list yet. Run buildIndex first.');
  else Logger.log('OK. ' + d.levels.length + ' levels, ' + json.length + ' characters, built ' + d.built + '. Teacher: ' + d.user.teacher);
}

/* ---------------------------------------------------------------
 *  One-time setup helpers (run from the editor)
 * ------------------------------------------------------------- */

/** Turns off download, print and copy for viewers on every file in the index.
 *  Needs the Drive API service added (Services → Drive API). Run again until the log says "Done". */
function lockDownloads() {
  const raw = loadIndex_();
  if (!raw) throw new Error('Run buildIndex first.');
  const data = JSON.parse(raw);
  const ids = [];
  data.levels.forEach(function (lv) {
    lv.topics.forEach(function (t) { t[3].forEach(function (f) { ids.push(f[1]); }); });
    lv.papers.forEach(function (p) { eachFile_(p.node, function (f) { ids.push(f[1]); }); });
    lv.collections.forEach(function (c) {
      if (c.file) ids.push(c.file[1]); else eachFile_(c.node, function (f) { ids.push(f[1]); });
    });
  });
  const props = PropertiesService.getScriptProperties();
  let i = +(props.getProperty('lockPos') || 0);
  const start = Date.now();
  let done = 0, skipped = 0;
  for (; i < ids.length; i++) {
    if (Date.now() - start > 270000) break;
    try { Drive.Files.update({ copyRequiresWriterPermission: true }, ids[i]); done++; }
    catch (e) { skipped++; }
  }
  if (i >= ids.length) { props.deleteProperty('lockPos'); Logger.log('Done. ' + ids.length + ' files checked.'); }
  else { props.setProperty('lockPos', String(i)); Logger.log('Progress ' + i + '/' + ids.length + '. Run lockDownloads again.'); }
  Logger.log('Updated ' + done + ', skipped ' + skipped + ' (files owned by someone else are skipped).');
}

/** Gives everyone at cch.edu.pk view access to the folders and files the site uses (not your whole Drive). */
function shareWithSchool() {
  const ids = [];
  CONFIG.LEVELS.forEach(function (L) {
    L.papers.forEach(function (p) { ids.push(p.id); });
    L.collections.forEach(function (c) { ids.push(c.file || c.folder); });
    L.topics.forEach(function (t) { t[3].forEach(function (f) { ids.push(f[1]); }); });
  });
  ids.forEach(function (id) {
    try {
      Drive.Permissions.create({ type: 'domain', role: 'reader', domain: CONFIG.SCHOOL_DOMAIN, allowFileDiscovery: false }, id);
    } catch (e) { Logger.log('Could not share ' + id + ': ' + e); }
  });
  Logger.log('Shared ' + ids.length + ' items with ' + CONFIG.SCHOOL_DOMAIN);
}

/** Refreshes the file list every night so new uploads appear on the site. */
function setupDailyRefresh() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'buildIndex') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('buildIndex').timeBased().everyDays(1).atHour(2).create();
  Logger.log('The file list will refresh every night at about 2 am.');
}

/* ---------------------------------------------------------------
 *  Helpers
 * ------------------------------------------------------------- */
function currentEmail_() { return (Session.getActiveUser().getEmail() || '').toLowerCase(); }

function saveIndex_(json) {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('indexFileId');
  let file = null;
  if (id) { try { file = DriveApp.getFileById(id); } catch (e) { file = null; } }
  if (file) file.setContent(json);
  else props.setProperty('indexFileId', DriveApp.createFile('biology-finder-index.json', json, 'application/json').getId());
  CacheService.getScriptCache().removeAll(['idx0', 'idx1', 'idx2', 'idx3', 'idx4', 'idx5', 'idx6', 'idx7', 'idxN']);
}

function loadIndex_() {
  const cache = CacheService.getScriptCache();
  const n = cache.get('idxN');
  if (n) {
    const keys = []; for (let i = 0; i < +n; i++) keys.push('idx' + i);
    const parts = cache.getAll(keys);
    if (keys.every(function (k) { return parts[k] != null; })) return keys.map(function (k) { return parts[k]; }).join('');
  }
  const id = PropertiesService.getScriptProperties().getProperty('indexFileId');
  if (!id) return null;
  const json = DriveApp.getFileById(id).getBlob().getDataAsString();
  const size = 90000, chunks = {};
  const count = Math.ceil(json.length / size);
  if (count <= 8) {
    for (let i = 0; i < count; i++) chunks['idx' + i] = json.slice(i * size, (i + 1) * size);
    chunks.idxN = String(count);
    try { cache.putAll(chunks, 21600); } catch (e) { /* cache is optional */ }
  }
  return json;
}

function kind_(mime) {
  if (mime === 'application/pdf') return 'pdf';
  if (mime === MimeType.GOOGLE_SLIDES) return 'gslide';
  if (mime === MimeType.GOOGLE_DOCS) return 'gdoc';
  if (mime === MimeType.GOOGLE_SHEETS) return 'gsheet';
  if (/presentation|powerpoint/.test(mime)) return 'ppt';
  if (/word|msword/.test(mime)) return 'doc';
  if (/sheet|excel/.test(mime)) return 'xls';
  if (/^image\//.test(mime)) return 'img';
  if (/^video\//.test(mime)) return 'vid';
  return 'file';
}

function fileYear_(name) {
  const m = /_[msw](\d{2})_/i.exec(name);
  return m ? 2000 + +m[1] : 0;
}

function eachFile_(node, fn) { node.f.forEach(fn); node.d.forEach(function (d) { eachFile_(d, fn); }); }

function countFiles_(data) {
  let n = 0;
  data.levels.forEach(function (lv) {
    lv.papers.forEach(function (p) { eachFile_(p.node, function () { n++; }); });
    lv.collections.forEach(function (c) { if (c.file) n++; else eachFile_(c.node, function () { n++; }); });
  });
  return n;
}

function natCmp_(a, b) {
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}


/* ---------------------------------------------------------------
 *  THE WEBSITE PAGE (sign-in screen first, then CCH Biology).
 *  You don't need to edit anything below this line.
 * ------------------------------------------------------------- */
function pageHtml_() {
  return [
    "<!DOCTYPE html>",
    "<html lang=\"en\">",
    "<head>",
    "<base target=\"_top\">",
    "<meta charset=\"utf-8\">",
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
    "<title>CCH Biology</title>",
    "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">",
    "<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Young+Serif&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap\">",
    "<style>",
    "/* Layout: sticky search band; home = three level cards; level = tabs (Topics / Past papers / Resources); files open in a full-screen viewer */",
    ":root{",
    "  --bg:#f4f7f3; --surface:#ffffff; --ink:#15211a; --muted:#56655b; --line:#d9e2db;",
    "  --leaf:#1d6b47; --leaf-soft:#e2efe7; --mark:#fff1a8; --lock:#8a5a12; --lock-soft:#fbf0dc;",
    "  --c-ppt:#b4532a; --c-pdf:#9b2f3a; --c-doc:#2d5ea8; --c-dir:#5b6b62;",
    "  --f-display:\"Young Serif\",Georgia,\"Times New Roman\",serif;",
    "  --f-body:\"IBM Plex Sans\",system-ui,-apple-system,\"Segoe UI\",sans-serif;",
    "  --f-mono:\"IBM Plex Mono\",ui-monospace,Menlo,Consolas,monospace;",
    "}",
    "@media (prefers-color-scheme:dark){:root{",
    "  --bg:#0f1612; --surface:#17211b; --ink:#e4ece6; --muted:#9aab9f; --line:#2a3830;",
    "  --leaf:#6fcf9d; --leaf-soft:#1e3328; --mark:#5a4d10; --lock:#f0c070; --lock-soft:#332a18;",
    "  --c-ppt:#f0956a; --c-pdf:#f08a94; --c-doc:#8fb3f0; --c-dir:#a6b5ac; color-scheme:dark}}",
    "*{box-sizing:border-box}",
    "html,body{margin:0}",
    "body{background:var(--bg);color:var(--ink);font:15px/1.55 var(--f-body);-webkit-user-select:none;user-select:none}",
    "input{-webkit-user-select:text;user-select:text}",
    "[hidden]{display:none!important}",
    "button{font:inherit;color:inherit;cursor:pointer}",
    "button:focus-visible,input:focus-visible{outline:2px solid var(--leaf);outline-offset:2px}",
    ".wrap{max-width:960px;margin:0 auto;padding-left:16px;padding-right:16px}",
    "",
    "header{position:sticky;top:0;z-index:5;background:var(--surface);border-bottom:1px solid var(--line)}",
    "header .wrap{padding-block:14px 12px;display:grid;gap:10px}",
    ".bar{display:flex;align-items:center;gap:12px;flex-wrap:wrap}",
    ".brand{background:none;border:0;padding:0;text-align:left}",
    ".brand h1{font:400 1.4rem/1.1 var(--f-display);margin:0}",
    ".brand h1 span{color:var(--leaf)}",
    ".user{margin-left:auto;display:flex;align-items:center;gap:8px;font-size:.8rem;color:var(--muted);min-width:0}",
    ".user .em{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:220px}",
    ".switch{font-weight:500;color:var(--leaf);text-decoration:none;border:1px solid var(--line);border-radius:6px;padding:3px 8px;white-space:nowrap}",
    ".switch:hover{border-color:var(--leaf)}",
    ".badge{font:500 .68rem var(--f-mono);letter-spacing:.04em;border-radius:4px;padding:2px 6px;background:var(--leaf-soft);color:var(--leaf)}",
    ".search{position:relative}",
    ".search input{width:100%;font:500 1rem var(--f-body);color:var(--ink);background:var(--bg);border:1.5px solid var(--line);border-radius:10px;padding:12px 40px 12px 42px;outline:none}",
    ".search input:focus{border-color:var(--leaf);background:var(--surface)}",
    ".search svg{position:absolute;left:14px;top:50%;transform:translateY(-50%);width:18px;height:18px;stroke:var(--muted)}",
    ".search .clear{position:absolute;right:6px;top:50%;transform:translateY(-50%);border:0;background:none;color:var(--muted);font-size:1.3rem;padding:4px 10px}",
    "",
    "main .wrap{padding-block:22px 64px;display:grid;gap:22px}",
    ".crumbs{display:flex;flex-wrap:wrap;gap:4px;align-items:center;font-size:.85rem;color:var(--muted)}",
    ".crumbs button{background:none;border:0;padding:2px 4px;color:var(--leaf);font-weight:500}",
    ".crumbs .sep{opacity:.5}",
    "h2{font:400 1.6rem/1.15 var(--f-display);margin:0;text-wrap:balance}",
    "h3{font:600 .72rem var(--f-body);text-transform:uppercase;letter-spacing:.09em;color:var(--muted);margin:8px 0 0}",
    ".sub{color:var(--muted);margin:4px 0 0;font-size:.92rem}",
    "",
    "/* home */",
    ".levels{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}",
    ".lvcard{display:grid;gap:6px;text-align:left;background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:18px}",
    ".lvcard:hover{border-color:var(--leaf)}",
    ".lvcard .code{font:500 .78rem var(--f-mono);color:var(--leaf)}",
    ".lvcard .nm{font:400 1.45rem var(--f-display)}",
    ".lvcard .stats{display:flex;gap:14px;flex-wrap:wrap;font-size:.82rem;color:var(--muted);font-variant-numeric:tabular-nums}",
    ".lvcard .stats b{color:var(--ink);font-weight:600}",
    ".quick{display:flex;gap:6px;flex-wrap:wrap;align-items:center;font-size:.82rem;color:var(--muted)}",
    ".quick button{border:0;background:var(--leaf-soft);color:var(--leaf);border-radius:6px;padding:4px 10px;font-size:.82rem}",
    "",
    "/* tabs */",
    ".tabs{display:flex;gap:4px;border-bottom:1px solid var(--line);overflow-x:auto}",
    ".tabs button{background:none;border:0;border-bottom:2.5px solid transparent;padding:10px 14px;font-weight:500;color:var(--muted);white-space:nowrap}",
    ".tabs button[aria-selected=\"true\"]{color:var(--ink);border-bottom-color:var(--leaf)}",
    "",
    "/* topics */",
    ".topics{display:grid;border:1px solid var(--line);border-radius:10px;background:var(--surface);overflow:hidden}",
    ".topic{display:grid;grid-template-columns:3rem 1fr;gap:4px 10px;padding:12px 14px;border-top:1px solid var(--line)}",
    ".topic:first-child{border-top:0}",
    ".topic .no{font:500 .85rem var(--f-mono);color:var(--leaf);padding-top:2px;font-variant-numeric:tabular-nums}",
    ".topic .name{font-weight:600;min-width:0}",
    ".topic .files{grid-column:2;display:flex;flex-wrap:wrap;gap:6px;min-width:0}",
    ".soon{font:500 .72rem var(--f-mono);letter-spacing:.04em;color:var(--muted);border:1px dashed var(--line);border-radius:5px;padding:2px 8px}",
    ".chip{display:inline-flex;align-items:center;gap:6px;font-size:.84rem;border:1px solid var(--line);border-radius:6px;padding:3px 9px 3px 4px;background:var(--bg);max-width:100%;text-align:left}",
    ".chip:hover{border-color:var(--leaf)}",
    ".chip .lbl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}",
    ".chip.locked{background:var(--lock-soft);border-color:transparent;color:var(--lock)}",
    ".tag{font:500 .62rem var(--f-mono);letter-spacing:.04em;border-radius:4px;padding:1px 5px;color:var(--surface);flex:none}",
    ".t-ppt{background:var(--c-ppt)}.t-pdf{background:var(--c-pdf)}.t-doc{background:var(--c-doc)}.t-dir,.t-file{background:var(--c-dir)}",
    "",
    "/* years */",
    ".set{display:grid;gap:10px}",
    ".years{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:8px}",
    ".year{display:grid;gap:2px;text-align:left;background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:10px 12px}",
    ".year:hover{border-color:var(--leaf)}",
    ".year .y{font:500 1.1rem var(--f-mono);font-variant-numeric:tabular-nums}",
    ".year .c{font-size:.75rem;color:var(--muted)}",
    ".year.locked{background:var(--lock-soft);border-color:transparent}",
    ".year.locked .c{color:var(--lock);font-weight:500}",
    "",
    "/* session tables */",
    ".filters{display:flex;gap:6px;flex-wrap:wrap}",
    ".filters button{border:1px solid var(--line);background:none;border-radius:999px;padding:4px 12px;font-size:.84rem;color:var(--muted)}",
    ".filters button[aria-pressed=\"true\"]{background:var(--leaf);border-color:var(--leaf);color:var(--surface)}",
    ".session{display:grid;gap:8px}",
    ".session h4{font:400 1.15rem var(--f-display);margin:0;display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}",
    ".session h4 small{font:500 .74rem var(--f-mono);color:var(--muted)}",
    ".tbl{border:1px solid var(--line);border-radius:10px;background:var(--surface);overflow-x:auto}",
    "table{border-collapse:collapse;width:100%;min-width:420px}",
    "th,td{text-align:left;padding:9px 12px;border-top:1px solid var(--line);vertical-align:middle}",
    "thead th{border-top:0;font:600 .7rem var(--f-body);text-transform:uppercase;letter-spacing:.08em;color:var(--muted);background:var(--bg)}",
    "td.p{font:500 .88rem var(--f-mono);white-space:nowrap;font-variant-numeric:tabular-nums}",
    "td .cell{display:flex;gap:6px;flex-wrap:wrap}",
    ".docs{display:flex;gap:6px;flex-wrap:wrap}",
    "",
    "/* resources + folders */",
    ".res{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:8px}",
    ".rcard{display:flex;gap:10px;align-items:flex-start;text-align:left;background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:11px 12px;min-width:0}",
    ".rcard:hover{border-color:var(--leaf)}",
    ".rcard .t{font-weight:500;font-size:.92rem;line-height:1.35;display:block}",
    ".rcard .d{font-size:.78rem;color:var(--muted);display:block;margin-top:2px}",
    ".list{display:grid;border:1px solid var(--line);border-radius:10px;background:var(--surface);overflow:hidden}",
    ".row{display:flex;gap:10px;align-items:center;text-align:left;background:none;border:0;border-top:1px solid var(--line);padding:10px 14px;width:100%;min-width:0}",
    ".row:first-child{border-top:0}",
    ".row:hover{background:var(--bg)}",
    ".row .lbl{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".row .meta{font-size:.76rem;color:var(--muted);white-space:nowrap}",
    ".row.locked .lbl{color:var(--lock)}",
    ".ico{width:18px;height:18px;flex:none;stroke:currentColor;fill:none;stroke-width:1.8}",
    "",
    "/* search */",
    ".results{display:grid;gap:8px}",
    ".r-count{font-size:.85rem;color:var(--muted)}",
    ".hit{display:flex;gap:10px;align-items:center;text-align:left;width:100%;background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:11px 14px;min-width:0}",
    ".hit:hover{border-color:var(--leaf)}",
    ".hit .body{flex:1;min-width:0;display:grid;gap:2px}",
    ".hit .ttl{font-weight:600;overflow:hidden;text-overflow:ellipsis}",
    ".hit .why{font-size:.8rem;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".hit .lv{font:500 .7rem var(--f-mono);color:var(--leaf);background:var(--leaf-soft);border-radius:4px;padding:1px 6px;flex:none}",
    ".hit.locked{background:var(--lock-soft);border-color:transparent}",
    "mark{background:var(--mark);color:inherit;border-radius:2px;padding:0 1px}",
    ".empty{padding:28px 0;color:var(--muted)}",
    ".empty b{color:var(--ink)}",
    ".state{display:grid;place-items:center;gap:10px;padding:80px 16px;text-align:center;color:var(--muted)}",
    ".spin{width:28px;height:28px;border:3px solid var(--line);border-top-color:var(--leaf);border-radius:50%;animation:sp 0.9s linear infinite}",
    "@keyframes sp{to{transform:rotate(360deg)}}",
    "footer{font-size:.78rem;color:var(--muted);border-top:1px solid var(--line);padding-top:14px}",
    "",
    "/* viewer */",
    ".viewer{position:fixed;inset:0;z-index:20;background:var(--bg);display:grid;grid-template-rows:auto 1fr}",
    ".vbar{display:flex;align-items:center;gap:10px;padding:10px 16px;background:var(--surface);border-bottom:1px solid var(--line);flex-wrap:wrap}",
    ".vbar .vt{flex:1;min-width:0}",
    ".vbar .vt b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".vbar .vt span{font-size:.78rem;color:var(--muted)}",
    ".btn{border:1px solid var(--line);background:var(--surface);border-radius:8px;padding:7px 12px;font-weight:500;font-size:.88rem}",
    ".btn:hover{border-color:var(--leaf)}",
    ".btn.primary{background:var(--leaf);border-color:var(--leaf);color:var(--surface)}",
    ".frame{position:relative;min-height:0}",
    ".frame iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:var(--surface)}",
    ".frame .spin{position:absolute;left:50%;top:40%;margin-left:-14px}",
    "",
    "/* locked message */",
    ".modal{position:fixed;inset:0;z-index:30;background:rgba(10,20,14,.45);display:grid;place-items:center;padding:16px}",
    ".mbox{background:var(--surface);border-radius:14px;max-width:400px;width:100%;padding:22px;display:grid;gap:10px;box-shadow:0 12px 40px rgba(0,0,0,.25)}",
    ".mbox .li{width:40px;height:40px;border-radius:10px;background:var(--lock-soft);color:var(--lock);display:grid;place-items:center}",
    ".mbox h5{font:400 1.25rem var(--f-display);margin:0}",
    ".mbox p{margin:0;color:var(--muted);font-size:.92rem}",
    ".mbox .btn{justify-self:end}",
    "",
    "@media (max-width:560px){.brand h1{font-size:1.2rem}.user .em{display:none}h2{font-size:1.35rem}.topic{grid-template-columns:2.3rem 1fr;padding:11px 12px}}",
    "@media (prefers-reduced-motion:reduce){.spin{animation-duration:3s}}",
    "",
    "/* sign-in gate: the first screen everyone sees */",
    ".gate{position:fixed;inset:0;z-index:40;background:var(--bg);display:grid;place-items:center;padding:24px 16px;overflow:auto}",
    ".gcard{width:100%;max-width:420px;background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:28px 24px;display:grid;gap:16px}",
    ".gcard .codes{font:500 .72rem var(--f-mono);letter-spacing:.05em;color:var(--leaf)}",
    ".gcard h1{font:400 1.8rem/1.1 var(--f-display);margin:4px 0 0}",
    ".gcard h1 span{color:var(--leaf)}",
    ".gcard p{margin:0;color:var(--muted)}",
    ".who{display:flex;align-items:center;gap:10px;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:10px 12px;min-width:0}",
    ".who .av{width:34px;height:34px;border-radius:50%;background:var(--leaf);color:var(--surface);display:grid;place-items:center;font-weight:600;flex:none;text-transform:uppercase}",
    ".who .em2{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}",
    ".who small{display:block;color:var(--muted);font-size:.75rem}",
    ".gbtn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;text-decoration:none;font:600 1rem var(--f-body);border-radius:10px;padding:13px 16px;border:1.5px solid var(--line);color:var(--ink);background:var(--surface);cursor:pointer}",
    ".gbtn:hover{border-color:var(--leaf)}",
    ".gbtn.primary{background:var(--leaf);border-color:var(--leaf);color:var(--surface)}",
    ".gbtn svg{width:20px;height:20px;flex:none}",
    ".gor{display:flex;align-items:center;gap:10px;color:var(--muted);font-size:.8rem}",
    ".gor::before,.gor::after{content:\"\";flex:1;height:1px;background:var(--line)}",
    ".gnote{font-size:.8rem;color:var(--muted);border-top:1px solid var(--line);padding-top:14px}",
    ".gwarn{background:var(--lock-soft);color:var(--lock);border-radius:10px;padding:12px 14px;font-size:.88rem}",
    "</style>",
    "</head>",
    "<body>",
    "<div class=\"gate\" id=\"gate\"><div class=\"gcard\"><div><div class=\"codes\">O LEVEL · IGCSE · A LEVEL</div><h1>CCH <span>Biology</span></h1></div><p>Checking your account…</p></div></div>",
    "",
    "<header><div class=\"wrap\">",
    "  <div class=\"bar\">",
    "    <button class=\"brand\" id=\"home\" aria-label=\"Go to home\"><h1>CCH <span>Biology</span></h1></button>",
    "    <div class=\"user\" id=\"user\"></div>",
    "  </div>",
    "  <div class=\"search\">",
    "    <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"2\" stroke-linecap=\"round\"><circle cx=\"11\" cy=\"11\" r=\"7\"/><path d=\"m20 20-3.5-3.5\"/></svg>",
    "    <input id=\"q\" type=\"search\" autocomplete=\"off\" placeholder=\"Search topics, papers or years: enzymes, s24 22, 2019 mark scheme…\" aria-label=\"Search all biology material\">",
    "    <button class=\"clear\" id=\"clear\" hidden aria-label=\"Clear search\">×</button>",
    "  </div>",
    "</div></header>",
    "",
    "<main><div class=\"wrap\" id=\"out\">",
    "  <div class=\"state\"><div class=\"spin\"></div>Checking your account and loading material…</div>",
    "</div></main>",
    "",
    "<div class=\"viewer\" id=\"viewer\" hidden>",
    "  <div class=\"vbar\">",
    "    <button class=\"btn\" id=\"vclose\">← Back</button>",
    "    <div class=\"vt\"><b id=\"vtitle\"></b><span id=\"vmeta\"></span></div>",
    "    <button class=\"btn primary\" id=\"vpair\" hidden></button>",
    "  </div>",
    "  <div class=\"frame\"><div class=\"spin\" id=\"vspin\"></div><iframe id=\"vframe\" title=\"Document viewer\" allow=\"autoplay\"></iframe></div>",
    "</div>",
    "",
    "<div class=\"modal\" id=\"modal\" hidden role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"mtitle\">",
    "  <div class=\"mbox\">",
    "    <div class=\"li\"><svg class=\"ico\" viewBox=\"0 0 24 24\"><rect x=\"5\" y=\"11\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 11V8a4 4 0 0 1 8 0v3\"/></svg></div>",
    "    <h5 id=\"mtitle\">Teachers only</h5>",
    "    <p id=\"mtext\">This file can only be accessed by teachers. Papers from the latest exam year open for students once the next year's papers are added.</p>",
    "    <button class=\"btn primary\" id=\"mok\">OK</button>",
    "  </div>",
    "</div>",
    "",
    "<script>var BOOT=<?!= boot ?>;</script>",
    "<script>",
    "var DATA=null, ALL=[], NAV=[], TEACHER=false;",
    "var SES={m:\"Feb/March\",s:\"May/June\",w:\"Oct/Nov\"}, SES_ORDER={m:0,s:1,w:2};",
    "var TYP={qp:\"Question paper\",ms:\"Mark scheme\",er:\"Examiner report\",gt:\"Grade thresholds\",ci:\"Confidential instructions\",in:\"Insert\",ir:\"Instructions\",sf:\"Source files\",pm:\"Pre-release\",sp:\"Specimen paper\",sm:\"Specimen mark scheme\"};",
    "var TAGS={ppt:[\"PPT\",\"ppt\"],gslide:[\"SLIDES\",\"ppt\"],pdf:[\"PDF\",\"pdf\"],doc:[\"DOC\",\"doc\"],gdoc:[\"DOC\",\"doc\"],xls:[\"XLS\",\"doc\"],gsheet:[\"SHEET\",\"doc\"],img:[\"IMG\",\"file\"],vid:[\"VIDEO\",\"file\"],file:[\"FILE\",\"file\"]};",
    "var LOCK_SVG='<svg class=\"ico\" viewBox=\"0 0 24 24\" style=\"width:14px;height:14px\"><rect x=\"5\" y=\"11\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 11V8a4 4 0 0 1 8 0v3\"/></svg>';",
    "var DIR_SVG='<svg class=\"ico\" viewBox=\"0 0 24 24\"><path d=\"M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/></svg>';",
    "var $=function(id){return document.getElementById(id)};",
    "var out=$(\"out\"), q=$(\"q\");",
    "",
    "function esc(s){return String(s==null?\"\":s).replace(/[&<>\"]/g,function(c){return{\"&\":\"&amp;\",\"<\":\"&lt;\",\">\":\"&gt;\",'\"':\"&quot;\"}[c]})}",
    "function tag(k){var t=TAGS[k]||TAGS.file;return '<span class=\"tag t-'+t[1]+'\">'+t[0]+'</span>'}",
    "function decode(name){",
    "  var m=/(\\d{4})_([msw])(\\d{2})_([a-z]{2})(?:_(\\d)(\\d)?)?/i.exec(name);",
    "  if(!m) return null;",
    "  return {code:m[1],ses:m[2].toLowerCase(),year:2000+ +m[3],type:m[4].toLowerCase(),paper:m[5]||\"\",variant:m[6]||\"\"};",
    "}",
    "function niceName(f){",
    "  var d=f.dec; if(!d) return f.name.replace(/\\.(pdf|pptx?|pptm|docx?|xlsx?)$/i,\"\");",
    "  var p=d.paper?(\" · Paper \"+d.paper+(d.variant||\"\")):\"\";",
    "  return d.code+\" · \"+SES[d.ses]+\" \"+d.year+p+\" · \"+(TYP[d.type]||d.type.toUpperCase());",
    "}",
    "function previewUrl(id,kind){",
    "  if(kind===\"gslide\") return \"https://docs.google.com/presentation/d/\"+id+\"/preview\";",
    "  if(kind===\"gdoc\") return \"https://docs.google.com/document/d/\"+id+\"/preview\";",
    "  if(kind===\"gsheet\") return \"https://docs.google.com/spreadsheets/d/\"+id+\"/preview\";",
    "  return \"https://drive.google.com/file/d/\"+id+\"/preview\";",
    "}",
    "function eachFile(node,path,fn){node.f.forEach(function(f){fn(f,path)});node.d.forEach(function(d){eachFile(d,path.concat(d.n),fn)})}",
    "function countNode(node){var n=0;eachFile(node,[],function(){n++});return n}",
    "",
    "/* ---------- data ---------- */",
    "function index(){",
    "  ALL=[];",
    "  DATA.levels.forEach(function(lv){",
    "    lv.topics.forEach(function(t){",
    "      ALL.push({t:\"topic\",lv:lv,topic:t,hay:(t[1]+\" \"+t[2]+\" \"+t[3].map(function(f){return f[0]}).join(\" \")+\" chapter \"+t[0]).toLowerCase()});",
    "    });",
    "    lv.papers.forEach(function(p){",
    "      eachFile(p.node,[p.label],function(f,path){",
    "        var o={t:\"paper\",lv:lv,name:f[0],id:f[1],kind:f[2],locked:!!f[3],path:path,dec:decode(f[0])};",
    "        var d=o.dec, extra=d?(\" \"+SES[d.ses]+\" \"+d.year+\" \"+d.ses+String(d.year).slice(2)+\" paper \"+d.paper+\" \"+d.paper+d.variant+\" \"+(TYP[d.type]||\"\")+\" \"+d.type):\"\";",
    "        o.hay=(f[0]+\" \"+path.join(\" \")+extra+\" past paper\").toLowerCase();",
    "        ALL.push(o);",
    "      });",
    "    });",
    "    lv.collections.forEach(function(c){",
    "      if(c.file) ALL.push({t:\"res\",lv:lv,name:c.name,id:c.file[1],kind:c.file[2],path:[c.name],hay:(c.name+\" \"+c.desc+\" \"+c.file[0]).toLowerCase()});",
    "      else eachFile(c.node,[c.name],function(f,path){",
    "        ALL.push({t:\"res\",lv:lv,name:f[0],id:f[1],kind:f[2],locked:!!f[3],path:path,dec:decode(f[0]),hay:(f[0]+\" \"+path.join(\" \")+\" \"+c.desc).toLowerCase()});",
    "      });",
    "    });",
    "  });",
    "}",
    "function pairOf(f){",
    "  if(!f.dec||(f.dec.type!==\"qp\"&&f.dec.type!==\"ms\")) return null;",
    "  var want=f.dec.type===\"qp\"?\"ms\":\"qp\", d=f.dec;",
    "  for(var i=0;i<ALL.length;i++){var o=ALL[i];if(o.dec&&o.dec.type===want&&o.dec.code===d.code&&o.dec.ses===d.ses&&o.dec.year===d.year&&o.dec.paper===d.paper&&o.dec.variant===d.variant) return o}",
    "  return null;",
    "}",
    "",
    "/* ---------- open / lock ---------- */",
    "var OPEN={};",
    "function reg(o){var k=\"k\"+Object.keys(OPEN).length;OPEN[k]=o;return k}",
    "function openFile(o){",
    "  if(!o.id){showLocked();return}",
    "  $(\"vtitle\").textContent=niceName(o);",
    "  $(\"vmeta\").textContent=o.lv.name+(o.path&&o.path.length?\" · \"+o.path.join(\" › \"):\"\")+(o.locked?\" · Teachers only\":\"\");",
    "  var p=pairOf(o), pb=$(\"vpair\");",
    "  if(p){pb.hidden=false;pb.textContent=\"Open \"+(p.dec.type===\"ms\"?\"mark scheme\":\"question paper\");pb.onclick=function(){openFile(p)}}else pb.hidden=true;",
    "  $(\"vspin\").hidden=false;",
    "  var fr=$(\"vframe\"); fr.onload=function(){$(\"vspin\").hidden=true}; fr.src=previewUrl(o.id,o.kind);",
    "  $(\"viewer\").hidden=false; document.body.style.overflow=\"hidden\"; $(\"vclose\").focus();",
    "}",
    "function closeViewer(){$(\"viewer\").hidden=true;$(\"vframe\").src=\"about:blank\";document.body.style.overflow=\"\"}",
    "function showLocked(){$(\"modal\").hidden=false;$(\"mok\").focus()}",
    "$(\"vclose\").onclick=closeViewer;",
    "$(\"mok\").onclick=function(){$(\"modal\").hidden=true};",
    "document.addEventListener(\"keydown\",function(e){",
    "  if(e.key===\"Escape\"){if(!$(\"modal\").hidden)$(\"modal\").hidden=true;else if(!$(\"viewer\").hidden)closeViewer();else if(q.value){q.value=\"\";render()}}",
    "  if((e.ctrlKey||e.metaKey)&&/^[sp]$/i.test(e.key)) e.preventDefault();",
    "});",
    "document.addEventListener(\"contextmenu\",function(e){e.preventDefault()});",
    "out.addEventListener(\"click\",function(e){",
    "  var b=e.target.closest(\"[data-k]\"); if(!b) return;",
    "  var o=OPEN[b.getAttribute(\"data-k\")]; if(!o) return;",
    "  if(typeof o===\"function\") o(); else openFile(o);",
    "});",
    "",
    "function chip(o,label){",
    "  return '<button class=\"chip'+(o.locked?' locked':'')+'\" data-k=\"'+reg(o)+'\">'+(o.locked?LOCK_SVG:tag(o.kind))+'<span class=\"lbl\">'+esc(label||niceName(o))+'</span></button>';",
    "}",
    "function act(fn){return reg(fn)}",
    "",
    "/* ---------- navigation ---------- */",
    "function go(state,push){if(push!==false)NAV.push(state);q.value=\"\";$(\"clear\").hidden=true;render();window.scrollTo(0,0)}",
    "function cur(){return NAV[NAV.length-1]||{p:\"home\"}}",
    "function crumbs(items){",
    "  return '<nav class=\"crumbs\">'+items.map(function(it,i){",
    "    if(i===items.length-1) return '<span>'+esc(it[0])+'</span>';",
    "    return '<button data-k=\"'+act(it[1])+'\">'+esc(it[0])+'</button><span class=\"sep\">›</span>';",
    "  }).join(\"\")+'</nav>';",
    "}",
    "function toHome(){NAV=[];go({p:\"home\"},false)}",
    "function toLevel(lv,tab){NAV=[{p:\"level\",lv:lv,tab:tab||\"topics\"}];render();window.scrollTo(0,0)}",
    "$(\"home\").onclick=toHome;",
    "",
    "/* ---------- pages ---------- */",
    "function render(){",
    "  OPEN={};",
    "  var v=q.value.trim();",
    "  $(\"clear\").hidden=!v;",
    "  if(!DATA) return;",
    "  if(v) return search(v);",
    "  if(!DATA) return;",
    "  var s=cur();",
    "  if(s.p===\"home\") return home();",
    "  if(s.p===\"level\") return level(s);",
    "  if(s.p===\"year\") return yearPage(s);",
    "  if(s.p===\"folder\") return folderPage(s);",
    "}",
    "",
    "function home(){",
    "  var html='<div><h2>Find any biology material in seconds</h2><p class=\"sub\">Slides by chapter, past papers by year and session, syllabuses and practical guides for Cambridge O Level, IGCSE and A Level.</p></div><div class=\"levels\">';",
    "  DATA.levels.forEach(function(lv){",
    "    var slides=lv.topics.filter(function(t){return t[3].length}).length, papers=0, years={};",
    "    lv.papers.forEach(function(p){papers+=countNode(p.node);p.node.d.forEach(function(d){if(/^\\d{4}$/.test(d.n.trim()))years[d.n]=1})});",
    "    var yr=Object.keys(years).sort();",
    "    html+='<button class=\"lvcard\" data-k=\"'+act(function(){toLevel(lv)})+'\"><span class=\"code\">'+esc(lv.code)+'</span><span class=\"nm\">'+esc(lv.name)+'</span><span class=\"stats\">'+",
    "      (lv.topics.length?'<span><b>'+slides+'</b>/'+lv.topics.length+' chapters with slides</span>':'')+",
    "      '<span><b>'+papers+'</b> past-paper files</span>'+(yr.length?'<span><b>'+yr[0]+'–'+yr[yr.length-1]+'</b></span>':'')+'</span></button>';",
    "  });",
    "  html+='</div><div class=\"quick\">Try: '+[\"photosynthesis\",\"s24 qp 22\",\"2023 mark scheme\",\"practical\",\"inheritance\",\"syllabus\"].map(function(t){return '<button data-k=\"'+act(function(){q.value=t;render()})+'\">'+t+'</button>'}).join(\"\")+'</div>';",
    "  html+=footer();",
    "  out.innerHTML=html;",
    "}",
    "",
    "function level(s){",
    "  var lv=s.lv, tabs=[];",
    "  if(lv.topics.length) tabs.push([\"topics\",\"Topics\"]);",
    "  tabs.push([\"papers\",\"Past papers\"],[\"res\",lv.key===\"ig\"?\"Syllabus & samples\":\"Resources\"]);",
    "  if(!tabs.some(function(t){return t[0]===s.tab})) s.tab=tabs[0][0];",
    "  var html=crumbs([[\"Home\",toHome],[lv.name]])+'<div><h2>'+esc(lv.name)+' Biology</h2><p class=\"sub\">Cambridge '+esc(lv.code)+'</p></div>';",
    "  html+='<div class=\"tabs\" role=\"tablist\">'+tabs.map(function(t){return '<button role=\"tab\" aria-selected=\"'+(t[0]===s.tab)+'\" data-k=\"'+act(function(){s.tab=t[0];render()})+'\">'+t[1]+'</button>'}).join(\"\")+'</div>';",
    "  if(s.tab===\"topics\") html+=topicsHtml(lv);",
    "  if(s.tab===\"papers\") html+=papersHtml(lv);",
    "  if(s.tab===\"res\") html+=resHtml(lv);",
    "  out.innerHTML=html+footer();",
    "}",
    "",
    "function topicsHtml(lv){",
    "  return '<div class=\"topics\">'+lv.topics.map(function(t){",
    "    var files=t[3].length?t[3].map(function(f){return chip({lv:lv,name:f[0],id:f[1],kind:f[2],path:[\"Ch \"+t[0]+\" \"+t[1]]},f[0])}).join(\"\"):'<span class=\"soon\">COMING SOON</span>';",
    "    return '<div class=\"topic\"><span class=\"no\">'+esc(t[0])+'</span><span class=\"name\">'+esc(t[1])+'</span><div class=\"files\">'+files+'</div></div>';",
    "  }).join(\"\")+'</div>';",
    "}",
    "",
    "/* Groups a papers folder into years: year folders plus files whose names carry a year code. */",
    "function buckets(p){",
    "  var by={}, others=[];",
    "  function add(y,f,path){(by[y]=by[y]||{year:y,files:[]}).files.push({f:f,path:path})}",
    "  p.node.d.forEach(function(d){",
    "    var nm=d.n.trim();",
    "    if(/^\\d{4}$/.test(nm)) eachFile(d,[nm],function(f,path){add(+nm,f,path)});",
    "    else {var hit=0;eachFile(d,[nm],function(f,path){var dc=decode(f[0]);if(dc){add(dc.year,f,path);hit++}});if(!hit)others.push(d)}",
    "  });",
    "  var loose=[];",
    "  p.node.f.forEach(function(f){var dc=decode(f[0]);if(dc)add(dc.year,f,[]);else loose.push(f)});",
    "  var locked=p.node.locked||[];",
    "  var list=Object.keys(by).map(function(y){var b=by[y];b.locked=locked.indexOf(+y)!==-1;return b}).sort(function(a,b){return b.year-a.year});",
    "  return {years:list,others:others,loose:loose};",
    "}",
    "",
    "function papersHtml(lv){",
    "  var html='';",
    "  lv.papers.forEach(function(p){",
    "    var b=buckets(p);",
    "    html+='<section class=\"set\">'+(lv.papers.length>1?'<h3>'+esc(p.label)+'</h3>':'')+'<div class=\"years\">';",
    "    b.years.forEach(function(y){",
    "      html+='<button class=\"year'+(y.locked?' locked':'')+'\" data-k=\"'+act(function(){go({p:\"year\",lv:lv,set:p,b:y,filter:\"all\"})})+'\"><span class=\"y\">'+y.year+'</span><span class=\"c\">'+(y.locked?(TEACHER?'Teachers only · open':'Teachers only'):y.files.length+' files')+'</span></button>';",
    "    });",
    "    html+='</div>';",
    "    if(b.others.length||b.loose.length){",
    "      html+='<h3>Other folders</h3><div class=\"list\">';",
    "      b.others.forEach(function(d){html+='<button class=\"row\" data-k=\"'+act(function(){go({p:\"folder\",lv:lv,root:p.label,trail:[d],tab:\"papers\"})})+'\">'+DIR_SVG+'<span class=\"lbl\">'+esc(d.n)+'</span><span class=\"meta\">'+countNode(d)+' files</span></button>'});",
    "      b.loose.forEach(function(f){var o={lv:lv,name:f[0],id:f[1],kind:f[2],locked:!!f[3],path:[p.label]};html+=rowFile(o)});",
    "      html+='</div>';",
    "    }",
    "    if(!b.years.length&&!b.others.length&&!b.loose.length) html+='<p class=\"empty\">No papers in this folder yet.</p>';",
    "    html+='</section>';",
    "  });",
    "  return html;",
    "}",
    "",
    "function yearPage(s){",
    "  var lv=s.lv, y=s.b;",
    "  var html=crumbs([[\"Home\",toHome],[lv.name,function(){toLevel(lv,\"papers\")}],[String(y.year)]]);",
    "  html+='<div><h2>'+esc(s.set.label)+' · '+y.year+'</h2><p class=\"sub\">'+y.files.length+' files'+(y.locked?(TEACHER?' · Locked for students, open for you':' · Teachers only: you can see the list but files open for teachers only'):'')+'</p></div>';",
    "  var F=[[\"all\",\"All\"],[\"qp\",\"Question papers\"],[\"ms\",\"Mark schemes\"],[\"er\",\"Examiner reports\"],[\"gt\",\"Grade thresholds\"]];",
    "  html+='<div class=\"filters\">'+F.map(function(f){return '<button aria-pressed=\"'+(s.filter===f[0])+'\" data-k=\"'+act(function(){s.filter=f[0];render()})+'\">'+f[1]+'</button>'}).join(\"\")+'</div>';",
    "  var ses={}, other=[];",
    "  y.files.forEach(function(x){",
    "    var f=x.f, o={lv:lv,name:f[0],id:f[1],kind:f[2],locked:!!f[3],path:[s.set.label,String(y.year)].concat(x.path.slice(1)),dec:decode(f[0])};",
    "    if(!o.dec){other.push(o);return}",
    "    if(s.filter!==\"all\"&&o.dec.type!==s.filter) return;",
    "    var S=ses[o.dec.ses]=ses[o.dec.ses]||{rows:{},docs:[]};",
    "    if(o.dec.paper){var k=o.dec.paper+o.dec.variant;(S.rows[k]=S.rows[k]||{k:k,cells:{}}).cells[o.dec.type]=o}",
    "    else S.docs.push(o);",
    "  });",
    "  Object.keys(ses).sort(function(a,b){return SES_ORDER[a]-SES_ORDER[b]}).forEach(function(k){",
    "    var S=ses[k], rows=Object.keys(S.rows).sort(function(a,b){return a.localeCompare(b,undefined,{numeric:true})}).map(function(r){return S.rows[r]});",
    "    html+='<section class=\"session\"><h4>'+SES[k]+' '+y.year+' <small>'+k+String(y.year).slice(2)+'</small></h4>';",
    "    if(S.docs.length) html+='<div class=\"docs\">'+S.docs.map(function(o){return chip(o,TYP[o.dec.type]||o.dec.type.toUpperCase())}).join(\"\")+'</div>';",
    "    if(rows.length){",
    "      var extra={};rows.forEach(function(r){Object.keys(r.cells).forEach(function(t){if(t!==\"qp\"&&t!==\"ms\")extra[t]=1})});",
    "      var ex=Object.keys(extra);",
    "      html+='<div class=\"tbl\"><table><thead><tr><th>Paper</th><th>Question paper</th><th>Mark scheme</th>'+(ex.length?'<th>Other</th>':'')+'</tr></thead><tbody>';",
    "      rows.forEach(function(r){",
    "        var c=r.cells;",
    "        html+='<tr><td class=\"p\">Paper '+esc(r.k)+'</td><td>'+(c.qp?chip(c.qp,\"QP \"+r.k):'<span class=\"soon\">—</span>')+'</td><td>'+(c.ms?chip(c.ms,\"MS \"+r.k):'<span class=\"soon\">—</span>')+'</td>'+",
    "          (ex.length?'<td><div class=\"cell\">'+ex.filter(function(t){return c[t]}).map(function(t){return chip(c[t],TYP[t]||t.toUpperCase())}).join(\"\")+'</div></td>':'')+'</tr>';",
    "      });",
    "      html+='</tbody></table></div>';",
    "    }",
    "    html+='</section>';",
    "  });",
    "  if(other.length&&s.filter===\"all\") html+='<h3>Other files</h3><div class=\"list\">'+other.map(rowFile).join(\"\")+'</div>';",
    "  if(!Object.keys(ses).length&&!(other.length&&s.filter===\"all\")) html+='<p class=\"empty\">Nothing of this type for '+y.year+'.</p>';",
    "  out.innerHTML=html+footer();",
    "}",
    "",
    "function resHtml(lv){",
    "  return '<div class=\"res\">'+lv.collections.map(function(c){",
    "    if(c.file){var o={lv:lv,name:c.name,id:c.file[1],kind:c.file[2],path:[c.name]};return '<button class=\"rcard\" data-k=\"'+reg(o)+'\">'+tag(c.file[2])+'<span><span class=\"t\">'+esc(c.name)+'</span><span class=\"d\">'+esc(c.desc)+'</span></span></button>'}",
    "    return '<button class=\"rcard\" data-k=\"'+act(function(){go({p:\"folder\",lv:lv,root:c.name,trail:[c.node],tab:\"res\"})})+'\"><span class=\"tag t-dir\">FOLDER</span><span><span class=\"t\">'+esc(c.name)+'</span><span class=\"d\">'+esc(c.desc)+' · '+countNode(c.node)+' files</span></span></button>';",
    "  }).join(\"\")+'</div>';",
    "}",
    "",
    "function rowFile(o){",
    "  return '<button class=\"row'+(o.locked?' locked':'')+'\" data-k=\"'+reg(o)+'\">'+(o.locked?LOCK_SVG:tag(o.kind))+'<span class=\"lbl\">'+esc(niceName(o))+'</span>'+(o.locked?'<span class=\"meta\">Teachers only</span>':'')+'</button>';",
    "}",
    "",
    "function folderPage(s){",
    "  var lv=s.lv, node=s.trail[s.trail.length-1];",
    "  var items=[[\"Home\",toHome],[lv.name,function(){toLevel(lv,s.tab)}]];",
    "  s.trail.forEach(function(n,i){items.push([i===0?s.root:n.n,i===s.trail.length-1?null:function(){s.trail=s.trail.slice(0,i+1);render()}])});",
    "  var path=[s.root].concat(s.trail.slice(1).map(function(n){return n.n}));",
    "  var html=crumbs(items)+'<div><h2>'+esc(s.trail.length===1?s.root:node.n)+'</h2><p class=\"sub\">'+node.d.length+' folders · '+node.f.length+' files</p></div><div class=\"list\">';",
    "  node.d.forEach(function(d){html+='<button class=\"row\" data-k=\"'+act(function(){s.trail=s.trail.concat([d]);render();window.scrollTo(0,0)})+'\">'+DIR_SVG+'<span class=\"lbl\">'+esc(d.n)+'</span><span class=\"meta\">'+countNode(d)+' files</span></button>'});",
    "  node.f.forEach(function(f){html+=rowFile({lv:lv,name:f[0],id:f[1],kind:f[2],locked:!!f[3],path:path,dec:decode(f[0])})});",
    "  if(!node.d.length&&!node.f.length) html+='<div class=\"row\"><span class=\"lbl\" style=\"color:var(--muted)\">This folder is empty.</span></div>';",
    "  out.innerHTML=html+'</div>'+footer();",
    "}",
    "",
    "/* ---------- search ---------- */",
    "function hl(text,terms){var s=esc(text);terms.forEach(function(t){if(t.length<2)return;s=s.replace(new RegExp(\"(\"+t.replace(/[.*+?^${}()|[\\]\\\\]/g,\"\\\\$&\")+\")\",\"ig\"),\"<mark>$1</mark>\")});return s}",
    "function search(raw){",
    "  var terms=raw.toLowerCase().split(/\\s+/).filter(Boolean), hits=[];",
    "  ALL.forEach(function(it){",
    "    for(var i=0;i<terms.length;i++) if(it.hay.indexOf(terms[i])===-1) return;",
    "    var score=it.t===\"topic\"?100:it.t===\"res\"?50:0;",
    "    if(it.dec) score+=it.dec.year-2000;",
    "    hits.push({it:it,score:score});",
    "  });",
    "  hits.sort(function(a,b){return b.score-a.score});",
    "  if(!hits.length){out.innerHTML='<div class=\"empty\"><b>Nothing matches “'+esc(raw)+'”.</b><br>Try a chapter name, a year like 2018, or a paper code like s23 qp 22.</div>';return}",
    "  var html='<div class=\"results\"><div class=\"r-count\">'+hits.length+' result'+(hits.length>1?'s':'')+(hits.length>100?', showing the first 100':'')+'</div>';",
    "  hits.slice(0,100).forEach(function(h){",
    "    var it=h.it, lvb='<span class=\"lv\">'+esc(it.lv.name)+'</span>';",
    "    if(it.t===\"topic\"){",
    "      var t=it.topic;",
    "      var files=t[3].length?t[3].map(function(f){return chip({lv:it.lv,name:f[0],id:f[1],kind:f[2],path:[\"Ch \"+t[0]+\" \"+t[1]]},f[0])}).join(\"\"):'<span class=\"soon\">COMING SOON</span>';",
    "      html+='<div class=\"hit\" style=\"display:grid;gap:8px\"><div style=\"display:flex;gap:8px;align-items:baseline;flex-wrap:wrap\">'+lvb+'<span class=\"ttl\">'+(typeof t[0]===\"number\"?\"Ch \"+t[0]+\" · \":\"\")+hl(t[1],terms)+'</span></div><div class=\"files\" style=\"display:flex;flex-wrap:wrap;gap:6px\">'+files+'</div></div>';",
    "    } else {",
    "      html+='<button class=\"hit'+(it.locked?' locked':'')+'\" data-k=\"'+reg(it)+'\">'+(it.locked?LOCK_SVG:tag(it.kind))+'<span class=\"body\"><span class=\"ttl\">'+hl(niceName(it),terms)+'</span><span class=\"why\">'+esc(it.path.join(\" › \"))+(it.locked?' · Teachers only':'')+'</span></span>'+lvb+'</button>';",
    "    }",
    "  });",
    "  out.innerHTML=html+'</div>';",
    "}",
    "q.addEventListener(\"input\",render);",
    "$(\"clear\").onclick=function(){q.value=\"\";render();q.focus()};",
    "",
    "function footer(){",
    "  var d=DATA.built?new Date(DATA.built):null;",
    "  return '<footer>Material from the Biology Department, Cadet College Hasanabdal. Files open here for viewing only. '+(d?'List updated '+d.toLocaleDateString(undefined,{day:\"numeric\",month:\"short\",year:\"numeric\"})+'.':'')+'</footer>';",
    "}",
    "",
    "/* ---------- start ---------- */",
    "var ICON_USER='<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><circle cx=\"12\" cy=\"8\" r=\"4\"/><path d=\"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6\"/></svg>';",
    "var ICON_MAIL='<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><rect x=\"3\" y=\"5\" width=\"18\" height=\"14\" rx=\"2\"/><path d=\"m3 7 9 6 9-6\"/></svg>';",
    "function gate(d){",
    "  var u=d.user||{}, sw=u.switchUrl||d.switchUrl, add=u.addUrl||d.addUrl, email=u.email||d.email||\"\";",
    "  var top='<div><div class=\"codes\">O LEVEL · IGCSE · A LEVEL</div><h1>CCH <span>Biology</span></h1></div>';",
    "  var others=(sw?'<a class=\"gbtn\" target=\"_top\" href=\"'+esc(sw)+'\">'+ICON_USER+'Use a different account</a>':'')+",
    "    (add?'<div class=\"gor\">or</div><a class=\"gbtn\" target=\"_top\" href=\"'+esc(add)+'\">'+ICON_MAIL+'Type email and password</a>':'');",
    "  var note='<div class=\"gnote\">College accounts are made by Cadet College Hasanabdal, so there is no sign-up here. If you don\\'t have one or forgot your password, ask the Biology Department or the IT office.</div>';",
    "  var html;",
    "  if(d.denied){",
    "    html=top+'<div class=\"gwarn\">'+(email?'<b>'+esc(email)+'</b> is not a college account. ':'')+'CCH Biology is only for <b>@cch.edu.pk</b> accounts.</div>'+",
    "      (sw?'<a class=\"gbtn primary\" target=\"_top\" href=\"'+esc(sw)+'\">'+ICON_USER+'Choose my @cch.edu.pk account</a>':'')+",
    "      (add?'<div class=\"gor\">or</div><a class=\"gbtn\" target=\"_top\" href=\"'+esc(add)+'\">'+ICON_MAIL+'Type email and password</a>':'')+note;",
    "  } else {",
    "    var first=email.split(\"@\")[0];",
    "    html=top+'<p>Slides, past papers and guides from the Biology Department. Check the account below, then continue.</p>'+",
    "      '<div class=\"who\"><span class=\"av\">'+esc(first.charAt(0)||\"?\")+'</span><span class=\"em2\">'+esc(email)+'<small>'+(u.teacher?'Teacher account':'Signed in')+'</small></span></div>'+",
    "      '<button class=\"gbtn primary\" id=\"gcontinue\">Continue as '+esc(first)+'</button>'+others+note;",
    "  }",
    "  $(\"gate\").firstChild.innerHTML=html;",
    "  var c=$(\"gcontinue\"); if(c){c.onclick=function(){$(\"gate\").hidden=true;window.scrollTo(0,0);q.focus()};c.focus()}",
    "}",
    "function start(json){",
    "  var d=JSON.parse(json);",
    "  gate(d);",
    "  if(d.denied){out.innerHTML='<div class=\"state\"><b>Cadet College Hasanabdal accounts only.</b>Sign in with your @cch.edu.pk Google account.'+(d.switchUrl?'<a class=\"btn primary\" target=\"_top\" href=\"'+esc(d.switchUrl)+'\" style=\"text-decoration:none\">Choose your @cch.edu.pk account</a>':'')+'</div>';return}",
    "  TEACHER=!!(d.user&&d.user.teacher);",
    "  $(\"user\").innerHTML='<span class=\"em\">'+esc(d.user?d.user.email:\"\")+'</span>'+(TEACHER?'<span class=\"badge\">TEACHER</span>':'')+(d.user&&d.user.switchUrl?'<a class=\"switch\" target=\"_top\" href=\"'+esc(d.user.switchUrl)+'\">Switch account</a>':'');",
    "  if(d.empty){out.innerHTML='<div class=\"state\"><b>The material list couldn\\'t be prepared.</b>'+(TEACHER?'<span>'+esc(d.error||\"Refresh the page in a minute.\")+'</span><span style=\"font-size:.85rem\">In the script editor, run buildIndex once and check the Execution log for the folder it names.</span>':'<span>Please try again in a few minutes.</span>')+'</div>';return}",
    "  DATA=d; index(); render();",
    "}",
    "function fail(msg){",
    "  clearTimeout(SLOW);",
    "  out.innerHTML='<div class=\"state\"><b>Couldn\\'t load the material.</b><span>'+esc(msg)+'</span><span style=\"font-size:.85rem\">If you are signed in to more than one Google account, open this link in an Incognito window and sign in with your @cch.edu.pk account only.</span></div>';",
    "}",
    "var SLOW=setTimeout(function(){",
    "  out.innerHTML='<div class=\"state\"><div class=\"spin\"></div><b>This is taking longer than usual.</b><span style=\"font-size:.88rem;max-width:440px\">If it stays like this, you are probably signed in to more than one Google account. Open the link in an Incognito (private) window and sign in with your @cch.edu.pk account only.</span></div>';",
    "},12000);",
    "window.addEventListener(\"error\",function(e){fail(\"Page error: \"+(e.message||\"unknown\"))});",
    "try{",
    "  if(typeof BOOT===\"object\"&&BOOT){clearTimeout(SLOW);start(JSON.stringify(BOOT))}",
    "  else if(!window.google||!google.script) throw new Error(\"Open the site through its Web app link (Deploy › Manage deployments), not as a file.\");",
    "  else google.script.run.withSuccessHandler(function(j){clearTimeout(SLOW);try{start(j)}catch(e){fail(\"Page error: \"+e.message)}})",
    "    .withFailureHandler(function(e){fail(e&&e.message?e.message:String(e))}).getData();",
    "}catch(e){fail(e.message)}",
    "</script>",
    "</body>",
    "</html>",
    ""
  ].join('\n');
}
